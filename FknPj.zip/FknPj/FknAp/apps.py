from django.apps import AppConfig


class FknapConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "FknAp"
